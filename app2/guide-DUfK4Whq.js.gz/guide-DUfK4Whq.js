import { A as e, D as t, E as n, F as r, G as i, M as a, O as o, P as s, Q as c, W as l, _ as u, a as d, b as f, ct as p, dt as m, ft as h, g, k as _, m as v, o as y, q as b, u as x, ut as S, x as C } from "./vlibras-initial-TiYwpGfM.js";
import { t as w } from "./zus-context-D0fmRUCc.js";
// src/widget/components/guide/actions.tsx
var T = () => {
	let t = A((e) => e.onClose), { status: n, gloss: i } = r(b("gloss", "status")), a = m(() => i && n === "idle", [i, n]);
	return /* @__PURE__ */ l("div", {
		className: "widget-radius absolute top-1 right-1 flex flex-col",
		children: [/* @__PURE__ */ l(e, {
			tabindex: 1,
			onClick: t,
			size: "icon-xs",
			"aria-label": "Fechar guia",
			children: /* @__PURE__ */ l(_, { name: "x" })
		}), a && /* @__PURE__ */ l(e, {
			tabindex: 1,
			"aria-label": "Repetir texto",
			onClick: g,
			size: "icon-xs",
			className: "animate-move-right",
			children: /* @__PURE__ */ l(_, { name: "repeat" })
		})]
	});
}, E = [
	{
		selector: "#header-menu-button",
		text: "Clique no Menu para acessar o Tradutor, o Dicionário ou saber mais sobre o VLibras.",
		gloss: "CLIQUE MENU ACESSAR TRADUTOR DICIONÁRIO SABER MAIS&QUANTIDADE SOBRE&ASSUNTO VLIBRAS",
		guideClx: "top-0! bottom-auto!",
		focus: !0
	},
	{
		selector: "#header-actions",
		text: "Aqui você pode aumentar o tamanho da janela e fechar a aplicação.",
		gloss: "AQUI VOCÊ PODER&POSSIBILIDADE AUMENTAR&TAMANHO JANELA FECHAR&INFORMÁTICA APLICAÇÃO",
		guideClx: "top-0! bottom-auto!"
	},
	{
		selector: "#toggle-avatar-button",
		text: "Aqui você pode alterar o avatar. Você pode escolher entre Ícaro, Hosana e Guga.",
		gloss: "AQUI VOCÊ PODER&POSSIBILIDADE TROCAR AVATAR [PONTO] VOCÊ PODER&POSSIBILIDADE ESCOLHER ENTRE [WLCM]ICARO_SINAL [WLCM]HOZANA_SINAL [WLCM]GUGA_SINAL ",
		guideClx: "top-auto! bottom-6.5!",
		guideClxExpanded: "mr-12!",
		focus: !0
	},
	{
		selector: "#main-action-speed-options",
		text: "Aqui você pode pausar, retomar, reiniciar ou alterar a velocidade da animação.",
		gloss: "AQUI VOCÊ PODER&POSSIBILIDADE RETOMAR RETOMAR REINICIAR OU ALTERAR VELOCIDADE ANIMAR",
		guideClx: "top-auto! bottom-0!"
	},
	{
		selector: "#emotions-subtitles-options",
		text: "Estas opções permitem alterar a emoção do avatar e ativar ou desativar as legendas.",
		gloss: "OPÇÃO PERMITIR&LIBERAR ALTERAR EMOÇÃO AVATAR ATIVAR OU DESATIVAR LEGENDA",
		guideClx: "top-auto! bottom-0!"
	},
	{
		selector: "#settings-option",
		text: "Opção para acessar as configurações do VLibras. Aqui você pode alterar o tema, regionalismo e transparência do fundo do avatar.",
		gloss: "OPÇÃO ACESSAR CONFIGURAÇÃO [PONTO] AQUI VOCÊ PODER&POSSIBILIDADE ALTERAR TEMA&ASSUNTO ALTERAR REGIONAL ALTERAR TRANSPARÊNCIA&NITIDEZ ALTERAR FUNDO&ATRÁS AVATAR",
		guideClx: "top-auto! bottom-0!"
	}
], D = () => {
	let t = S(null), n = S(null), { index: r, setIndex: i, onClose: a } = A(b("index", "setIndex", "onClose")), o = m(() => r === 0, [r]), s = m(() => r === E.length - 1, [r]);
	return p(() => t.current?.focus(), [o]), p(() => n.current?.focus(), [s]), /* @__PURE__ */ l("div", {
		className: "flex items-center justify-between gap-2",
		children: [
			/* @__PURE__ */ l(e, {
				tabindex: 2,
				ref: n,
				disabled: o,
				variant: "ghost",
				size: "sm",
				className: "text-primary-foreground outline-primary-foreground hover:bg-primary-foreground/5",
				onClick: () => i(r - 1),
				children: [/* @__PURE__ */ l(_, { name: "arrow-left" }), "Voltar"]
			}),
			/* @__PURE__ */ l("div", {
				className: "flex h-4 w-40 items-center justify-center gap-1 [&_span]:rounded-full [&_span]:bg-primary-foreground/30",
				children: E.map((e, t) => /* @__PURE__ */ l("span", {
					"data-active": t === r,
					className: "size-2 rounded-full data-[active=true]:bg-primary-foreground!"
				}, t))
			}),
			/* @__PURE__ */ l(e, {
				tabindex: 2,
				ref: t,
				variant: "ghost",
				size: "sm",
				className: "text-primary-foreground outline-primary-foreground hover:bg-primary-foreground/5",
				onClick: s ? a : () => i((e) => e + 1),
				children: [s ? "Concluir" : "Avançar", !s && /* @__PURE__ */ l(_, { name: "arrow-right" })]
			})
		]
	});
}, O = a("absolute flex flex-col gap-4 z-50 widget-radius bg-primary p-4 transition-position", {
	variants: {
		isMobile: {
			true: "",
			false: ""
		},
		isLeft: {
			true: "",
			false: ""
		},
		isTop: {
			true: "",
			false: ""
		},
		isExpanded: {
			true: "",
			false: ""
		}
	},
	compoundVariants: [
		{
			isExpanded: !1,
			class: "w-screen max-w-xs"
		},
		{
			isMobile: !1,
			isExpanded: !1,
			isLeft: !0,
			class: "top-0 -right-3 translate-x-full"
		},
		{
			isMobile: !1,
			isExpanded: !1,
			isLeft: !1,
			class: "top-0 -left-3 -translate-x-full"
		},
		{
			isMobile: !0,
			isExpanded: !1,
			isTop: !0,
			class: "inset-x-0 -bottom-2 left-1/2 min-w-xs -translate-x-1/2 translate-y-full"
		},
		{
			isMobile: !0,
			isExpanded: !1,
			isTop: !1,
			class: "inset-x-0 -top-2 left-1/2 min-w-xs -translate-x-1/2 -translate-y-full"
		},
		{
			isExpanded: !0,
			class: "z-2147483647 inset-x-4 bottom-16"
		}
	],
	defaultVariants: {
		isMobile: !1,
		isExpanded: !1,
		isLeft: !1,
		isTop: !1
	}
}), { Provider: k, useCtx: A } = w(), j = () => {
	let { pos: e } = x(), { innerWidth: r, innerHeight: a } = window, [g, _] = h(0), b = C(), S = t((e) => e.isExpanded), w = t((e) => e.isTranslating), A = n((e) => e.appRoot), j = c(), M = m(() => e.x < (r - (A?.clientWidth || 0)) / 2, [e.x, r]), N = m(() => e.y < (a - (A?.clientHeight || 0)) / 2, [e.y, a]), P = m(() => E[g], [g]), F = () => {
		o.set({ text: void 0 }), s.set({ gloss: void 0 }), f.get().reset(), I(), u();
	};
	if (p(() => void (w && F()), [w]), p(() => {
		if (!A) return;
		I(), v(P.gloss), P.action?.();
		let e = d(P.selector, A);
		e && (f.set({ element: P }), e.dataset.highlight = "true", P.focus && e.focus());
	}, [P]), !A) return null;
	let I = () => {
		A && y("[data-highlight=true]", A)?.forEach((e) => e.dataset.highlight = "false");
	};
	return /* @__PURE__ */ l(k, {
		data: {
			index: g,
			setIndex: _,
			onClose: F,
			...b
		},
		children: /* @__PURE__ */ l("div", {
			className: i(O({
				isMobile: j,
				isLeft: M,
				isTop: N,
				isExpanded: S
			}), !S && !j && P.guideClx, S && P.guideClxExpanded),
			children: [
				/* @__PURE__ */ l("div", {
					className: "pr-4",
					children: /* @__PURE__ */ l("span", {
						className: "break-anywhere expanded:text-base! mobile:text-sm text-base text-primary-foreground",
						children: P.text
					})
				}),
				/* @__PURE__ */ l(T, {}),
				/* @__PURE__ */ l(D, {}),
				!S && /* @__PURE__ */ l("span", { className: i("absolute -z-10 my-4 size-4 rotate-45 rounded-xs bg-primary max-lg:hidden", P.guideClx, M ? "-left-1" : "-right-1") })
			]
		})
	});
};
export { j as Guide };
